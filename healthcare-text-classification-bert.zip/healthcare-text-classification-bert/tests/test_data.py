import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from healthcare_nlp.data import load_labeled_csv


def test_load_labeled_csv_removes_blank_rows(tmp_path):
    path = tmp_path / "notes.csv"
    pd.DataFrame({"text": ["valid note", "  "], "label": ["a", "b"]}).to_csv(path, index=False)
    result = load_labeled_csv(path)
    assert len(result) == 1
    assert result.iloc[0]["text"] == "valid note"


def test_load_labeled_csv_requires_columns(tmp_path):
    path = tmp_path / "notes.csv"
    pd.DataFrame({"sentence": ["example"]}).to_csv(path, index=False)
    with pytest.raises(ValueError, match="Missing required columns"):
        load_labeled_csv(path)
