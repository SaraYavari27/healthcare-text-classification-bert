from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import Dataset


def load_labeled_csv(path: str | Path, text_column: str = "text", label_column: str = "label") -> pd.DataFrame:
    """Load and validate a labeled UTF-8 CSV."""
    frame = pd.read_csv(path)
    missing = {text_column, label_column} - set(frame.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    frame = frame[[text_column, label_column]].dropna().copy()
    frame[text_column] = frame[text_column].astype(str).str.strip()
    frame[label_column] = frame[label_column].astype(str).str.strip()
    frame = frame[(frame[text_column] != "") & (frame[label_column] != "")]
    if frame.empty:
        raise ValueError("The dataset contains no valid labeled text rows.")
    return frame.reset_index(drop=True)


class ClinicalTextDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length: int = 128):
        self.texts = list(texts)
        self.labels = list(labels)
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, index):
        encoded = self.tokenizer(
            self.texts[index], truncation=True, padding="max_length",
            max_length=self.max_length, return_tensors="pt"
        )
        item = {key: value.squeeze(0) for key, value in encoded.items()}
        item["labels"] = torch.tensor(self.labels[index], dtype=torch.long)
        return item
